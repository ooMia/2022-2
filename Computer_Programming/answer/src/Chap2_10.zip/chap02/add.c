#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	printf("2+5=%d\n", 2 + 3);
	printf("2-3=%d\n", 2 - 3);
	printf("2*3=%d\n", 2 * 3);
	printf("2/3=%d\n", 2 / 3);
	return 0;
}
