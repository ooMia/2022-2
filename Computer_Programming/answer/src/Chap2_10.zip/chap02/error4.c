#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	printf("Hey!");			// ��
	printf("Good Morning");		// ��
	return 0;
}