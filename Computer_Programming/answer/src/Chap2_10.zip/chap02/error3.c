#define _CRT_SECURE_NO_WARNINGS
/* ù ��° ���α׷� */
#include <stdio.h>

int main(void)
{
	print("Hello World!");
	return 0;
}