#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	printf("Hello World!\n");
	printf("Kim ChulSoo \n");

	return 0;
}
