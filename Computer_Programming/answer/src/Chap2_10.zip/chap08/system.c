#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

int main( void )
{
	system("dir");
	printf("�ƹ� Ű�� ġ����\n");
	_getch();
	system("cls");

	return 0;
}