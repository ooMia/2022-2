#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

extern void f2();
int main(void)
{
	f2();
	return 0;
}
