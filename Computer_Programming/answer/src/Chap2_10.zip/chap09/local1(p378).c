#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	int temp;

	printf("temp = %d\n", temp);
	return 0;
}
