#define _CRT_SECURE_NO_WARNINGS
int z;
