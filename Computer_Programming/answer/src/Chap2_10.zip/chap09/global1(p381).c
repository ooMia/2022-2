#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int counter;	

int main(void)
{
	printf("counter=%d\n", counter);
	return 0;
}