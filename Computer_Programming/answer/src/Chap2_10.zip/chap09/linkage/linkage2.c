#define _CRT_SECURE_NO_WARNINGS
extern int all_files;

void sub(void)
{
	all_files = 10;
}
