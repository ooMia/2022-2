public class Ticket {
    private int serialNum;

    public int getSerialNum() {
        return serialNum;
    }

    public Ticket(int serialNum) {
        this.serialNum = serialNum;
    }
}
