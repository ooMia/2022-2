# -*- coding: utf-8 -*-
# A* 탐색 프로그램(경로 출력 기능 추가)

import time

import queue          # 우선순위 큐(PriorityQueue)를 사용하기 위해

# 상태를 나타내는 클래스
class State :
    def __init__(self, board, goal, moves='-') :      # 생성자, '-' move는 루트
        self.board = board
        self.moves = moves
        self.goal = goal
        
    # i1과 i2를 교환하여서 새로운 상태를 반환한다.
    def get_new_board(self, i1, i2, moves) :
        new_board = self.board[:]
        new_board[i1], new_board[i2] = new_board[i2], new_board[i1]
        return State(new_board, self.goal, moves)
    
    # 자식 노드를 확장하여서 리스트에 저장하여 반환한다.
    def expand(self) :
        result = []
        i = self.board.index(0)         # 숫자 0(빈칸)의 위치를 찾는다.
        if not i in [0,1,2] :           # UP
            result.append(self.get_new_board(i, i-3, self.moves+'U'))
        if not i in [0,3,6] :           # LEFT
            result.append(self.get_new_board(i, i-1, self.moves+'L'))
        if not i in [2,5,8] :           # RIGHT
            result.append(self.get_new_board(i, i+1, self.moves+'R'))
        if not i in [6,7,8] :           # DOWN
            result.append(self.get_new_board(i, i+3, self.moves+'D'))
        return result
    
    # 객체를 출력할 때 사용한다.
    def __str__(self) :
        return str(self.board[:3]) + "\t" + 'f(n)=' + str(self.f()) +"\n"+\
        str(self.board[3:6]) + "\t" + 'g(n)=' + str(self.g()) + "\n"+\
        str(self.board[6:]) + "\t" + 'h(n)=' + str(self.h()) + "\n"+\
        "-----------------"
    
    # f(n) 계산 함수
    def f(self) :
        return self.h() + self.g()
    
    # 휴리스틱 함수인 h(n) 계산
    # 현재 제 위치에 있지 않은 타일의 개수를 리스트 함축으로 계산한다.
    def h(self) :
        return sum([1 if self.board[i] != self.goal[i] else 0 for i in range(9)])
    
    def g(self) :
        return len(self.moves)-1
    
    def __lt__(self, other) :
        return self.f() < other.f()

def isBoardIn(st, qu) :
    for item in qu :
        if (st.board == item.board):
            return True
    return False

# program to check if a given instance of 8 puzzle is solvable or not
# A utility function to count
# inversions in given array 'arr[]'
def getInvCount(arr):
    inv_count = 0
    empty_value = 0            # -1 or 0
    for i in range(0, 9):
        for j in range(i + 1, 9):
            if arr[j] != empty_value and arr[i] != empty_value and arr[i] > arr[j]:
                inv_count += 1
    return inv_count
      
# This function returns true
# if given 8 puzzle is solvable only when goal is [1,2,3,4,5,6,7,8,0]
def isSolvable(puzzle) :
    # Count inversions in given 8 puzzle
    # inv_count = getInvCount([j for sub in puzzle for j in sub])   # 2차원 puzzle 표현시
    inv_count = getInvCount(puzzle)
 
    # return true if inversion count is even.
    return (inv_count % 2 == 0)
'''     
# Driver code
puzzle = [[8, 1, 2],[-1, 4, 3],[7, 6, 5]]
if(isSolvable(puzzle)) :
    print("Solvable")
else :
    print("Not Solvable")
     
    # This code is contributed by vitorhugooli
    # Fala meu povo desse Brasil varonil 
'''

# show state path from start node using moves info
def show_goal_path(start, moves) :
    print('*** Print path from start state to goal state ***')
    print(start)
    cur = start
    cur.moves = '-'
    moves = moves[1:]       # skip start node
    for m in moves :
        i = cur.board.index(0)
        if m == 'U' :
            cur.board[i], cur.board[i-3] = cur.board[i-3], cur.board[i]
        elif m == 'L' :
            cur.board[i], cur.board[i-1] = cur.board[i-1], cur.board[i]
        elif m == 'R' :
            cur.board[i], cur.board[i+1] = cur.board[i+1], cur.board[i]
        elif m == 'D' :
            cur.board[i], cur.board[i+3] = cur.board[i+3], cur.board[i]
        else :
            print('Error!', m, 'Unknown move')
            return
        cur.moves += m
        print(cur)
    print('*** Done ***')
    

# main
# input: 1 2 3 4 5
# output: [1, 2, 3, 4, 5]
# numbers = list(map(int, input().split()))

# 8-퍼즐
puzzle = [1,2,3,0,4,6,7,5,8]
# Not solvable with [8,1,2,0,4,3,7,6,5], Solvable with [1,8,2,0,4,3,7,6,5] or
# [8,0,6,5,2,4,7,3,1]
goal = [1,2,3,4,5,6,7,8,0]

# 또 다른 8-퍼즐
puzzle2 = [2,8,3,1,6,4,7,0,5]
goal2 = [1,2,3,8,0,4,7,6,5]

# puzzle과 goal2 또는 puzzle2와 goal로 테스트하면 탐색 실패되니 확인해 볼 것!

print("8-퍼즐 A* 탐색 프로그램 테스트")
print("8-퍼즐 상태를 제대로 입력하지 않고 그냥 enter 키를 치면 종료됨!")
while True:  
    # 초기 상태
    print("8-퍼즐의 초기 상태인 9개 원소를 공백으로 차례로 입력하고 enter 키를 누르시오.")
    print("8-퍼즐의 빈 칸은 0 으로, 그외는 숫자로 입력하면 됩니다.")
    puzzle = list(map(int, input().split()))
    if len(puzzle) < 1 : break
    '''
    puzzle = []
    for _ in range(n):
        label.append(random.randint(9))
    '''
    print("초기 상태 =", puzzle)
    
    # 목표 상태
    print("8-퍼즐의 목표 상태인 9개 원소를 공백으로 차례로 입력하고 enter 키를 누르시오.")
    goal = list(map(int, input().split()))
    if len(goal) < 1 : break
    '''
    goal = []
    for _ in range(n):
        goal.append(random.randint(9))
    '''
    print("목표 상태 =", goal)

    # check if the given 8-puzzle is solvable or not for avoiding infinite search
    if(goal == [1,2,3,4,5,6,7,8,0] and not isSolvable(puzzle)) :
        print("Given 8-puzzle is Not Solvable!")
        chk = input("Try again with other 8-puzzle? Answer Y or N. ")
        if chk == 'Y' or chk == 'y':
            continue
        else :
            break

    t1 = time.time()  
    # open 리스트를 우선순위큐로 추가 생성
    open_qu = []                        # 중복 검사용
    start = State(puzzle, goal)
    open_qu.append(start)
    open_pqu = queue.PriorityQueue()    # 후보 선택용
    open_pqu.put(start)

    closed_qu = []
    # moves = 0
    n_states = 1                            # Satet 노드의 개수
    print('A* 탐색에 의한 8-puzzle')
    while not open_pqu.empty() :
        #for 디버깅
        #print('Start of openQ')
        #for e in open_qu :
        #    print(e)
        #print('End of openQ')
        current = open_pqu.get()
        # print(current)                  # can skip it for speed up
        if current.board == goal :
            print('A* 탐색 성공 after', n_states, "상태 노드들 생성")
            print("탐색경로 정보:", current.moves, '(', len(current.moves)-1, ')')
            break
        # moves = current.moves + 1
        
        # 지나친 깊이 탐색을 방지하기 위하여, 추후 조정 가능
        #if moves > 10 and open_pqu.qsize() > 0:     # if moves = 15, 실패?
        #    continue
        
        closed_qu.append(current)
        for st in current.expand() :
    #        if (st in closed_qu) or (st in open_qu) :
            if isBoardIn(st, closed_qu) or isBoardIn(st, open_qu) :
                continue
            else :
                open_qu.append(st)
                open_pqu.put(st)
                n_states += 1
    t2 = time.time()
    print("실행 시간(sec):", t2-t1)
    if current.board != goal :
        print('A* 탐색 실패! after', n_states, "상태 노드들 생성")
    print("open pqu:", open_pqu.qsize(), "개", "closed qu:", len(closed_qu), "개")
    show_goal_path(start, current.moves)
    
