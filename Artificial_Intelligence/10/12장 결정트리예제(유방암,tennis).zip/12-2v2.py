# 유방암 데이터를 이용한 결정 트리 학습과 예측
'''
아래 명령어 문장을 먼저 아나콘다 프롬프트 창에서 실행시켜야 함.
conda install python-graphviz
conda install pydotplus
또는 명령어 창에서
graphviz 프로그램을 다운로드하여 설치한 다음,
bin 폴더를 시스템 path 정보에 추가하고, 아래 명령어 실행시킬 것.
python -m pip install graphviz
'''
from sklearn.datasets import load_breast_cancer
from sklearn import tree
import pydotplus

wdbc=load_breast_cancer()

decision_tree=tree.DecisionTreeClassifier(random_state=1)   # max_depth=4
dt=decision_tree.fit(wdbc.data,wdbc.target)                 # 결정 트리 학습

res=dt.predict(wdbc.data)
print('결정 트리의 정확률=',sum(res==wdbc.target)/len(res)) # 예측

dot=tree.export_graphviz(dt,out_file=None,feature_names=wdbc.feature_names,class_names=wdbc.target_names,filled=True,node_ids=True,rounded=True)
graph=pydotplus.graph_from_dot_data(dot)

# 아래 두 코드가 오류가 발생하면 코멘트 처리하고, png 형식의 그림 화일을 따로 보면 됨!
'''
import os
os.environ['PATH']=os.environ['PATH']+';'+os.environ['CONDA_PREFIX']+r"\Library\bin\graphviz"
'''
graph.write_png('tree.png')         # 결정 트리를 위한 그림 저장

x_test=wdbc.data[0:1]               # 0번 샘플이 결정 트리의 루트부터 타고 내려가게 하기
path=dt.decision_path(x_test)
path_seq=path.toarray()[0]

for n,value in enumerate(path_seq):
    node=graph.get_node(str(n))[0]      # node.get_attributes()로 세부 정보 보기 가
    if value==0:
        node.set_fillcolor('white')
    else:
        node.set_fillcolor('green')     # 의사결정 경로를 green 색으로 표시

graph.write_png('tree_with_path.png')   # 의사결정 경로를 포함한 그림 저장


# csv 화일로부터 결정트리 만들기
import pandas as pd
import numpy as np

f = open('tennis.csv', 'r')
t_data = pd.read_csv(f, header=0)   # first row used as the column names
x_train = np.ndarray((len(t_data),4))    # t_data[['Outlook','Temperature','Humidity','Windy']]
y_train = np.ndarray(len(t_data))    # t_data[['PlayTennis']]
cols = ['Outlook','Temperature','Humidity','Windy','PlayTennis']
wd_set = set({'Outlook','Temperature','Humidity','Windy','PlayTennis'})
for w in cols :
    wd_set = wd_set.union(set(t_data[w]))
wd_dic = {}
inx_dic = {}
wd_l = list(wd_set)
i = 1
for wd in wd_l :        # word to index transformation
    wd_dic[wd] = i
    inx_dic[i] = wd
    i += 1
for w in ['Outlook','Temperature','Humidity','Windy'] :
    for r in range(len(t_data)) :
        if t_data[w][r] in wd_dic.keys() :      # [col][row] format
            x_train[r][cols.index(w)] = wd_dic[t_data[w][r]]
        else :
            x_train[r][cols.index(w)] = 0
for r in range(len(t_data)) :
    if t_data['PlayTennis'][r] in wd_dic.keys() :      # [col][row] format
        y_train[r] = wd_dic[t_data['PlayTennis'][r]]
    else :
        y_train[r] = 0

tennis_tree = tree.DecisionTreeClassifier(random_state=1)
tt = tennis_tree.fit(x_train, y_train)
res = tt.predict(x_train)
print('결정 트리의 정확률=',sum(res==y_train)/len(res)) # 예측
# unknown 관찰 결과에 대한 예측 결과는?
# 'Sunny', 'Hot', 'Normal', 'Weak'  -> 'Yes' ?
# 'Rain', 'Hot', 'High', 'Weak'  -> 'Yes' ?
res1 = tt.predict([[wd_dic['Sunny'], wd_dic['Hot'], wd_dic['Normal'], wd_dic['Weak']]])
print('"Sunny,Hot,Normal,Weak"에 대한 결정 트리의 PlayTennis 결과는?', inx_dic[res1[0]])
dot=tree.export_graphviz(tt,out_file=None,feature_names=['Outlook','Temperature','Humidity','Windy'],class_names=['No','Yes'],filled=True,node_ids=True,rounded=True)
graph=pydotplus.graph_from_dot_data(dot)
graph.write_png('tennis1.png')         # 결정 트리를 위한 그림 저장

x_test=[[wd_dic['Sunny'], wd_dic['Hot'], wd_dic['Normal'], wd_dic['Weak']]]   # 샘플이 결정 트리의 루트부터 타고 내려가게 하기
path=tt.decision_path(x_test)
path_seq=path.toarray()[0]

for n,value in enumerate(path_seq):
    node=graph.get_node(str(n))[0]      # node.get_attributes()로 세부 정보 보기 가
    if value==0:
        node.set_fillcolor('white')
    else:
        node.set_fillcolor('green')     # 의사결정 경로를 green 색으로 표시

graph.write_png('tennis1_with_path.png')   # 의사결정 경로를 포함한 그림 저장

tennis_tree2 = tree.DecisionTreeClassifier(criterion='entropy',random_state=1)
tt2 = tennis_tree2.fit(x_train, y_train)
res = tt2.predict(x_train)
print('결정 트리의 정확률=',sum(res==y_train)/len(res)) # 예측

res2 = tt2.predict([[wd_dic['Rain'], wd_dic['Hot'], wd_dic['High'], wd_dic['Weak']]])
print('"Rain,Hot,High,Weak"에 대한 결정 트리의 PlayTennis 결과는?', inx_dic[res2[0]])
dot2=tree.export_graphviz(tt2,out_file=None,feature_names=['Outlook','Temperature','Humidity','Windy'],class_names=['No','Yes'],filled=True,node_ids=True,rounded=True)
graph2=pydotplus.graph_from_dot_data(dot2)
graph2.write_png('tennis2.png')         # 결정 트리를 위한 그림 저장

x_test2=[[wd_dic['Rain'], wd_dic['Hot'], wd_dic['High'], wd_dic['Weak']]]   # 샘플이 결정 트리의 루트부터 타고 내려가게 하기
path2=tt2.decision_path(x_test2)
path2_seq=path.toarray()[0]

for n,value in enumerate(path2_seq):
    node=graph2.get_node(str(n))[0]      # node.get_attributes()로 세부 정보 보기 가
    if value==0:
        node.set_fillcolor('white')
    else:
        node.set_fillcolor('green')     # 의사결정 경로를 green 색으로 표시

graph2.write_png('tennis2_with_path.png')   # 의사결정 경로를 포함한 그림 저장
