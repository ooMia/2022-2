from sklearn.linear_model import Perceptron

print('AND 퍼셉트론')

X = [[0,0],[0,1],[1,0],[1,1]]
y = [0,0,0,1]

# 퍼셉트론 생성, tol은 종료 조건, random_state는 난수의 시드
clf = Perceptron(tol=1e-3, random_state=0)

# 학습
clf.fit(X,y)

# 테스트 수행
print(X, '=>', clf.predict(X))


print('OR 퍼셉트론')

X = [[0,0],[0,1],[1,0],[1,1]]
y = [0,1,1,1]

# 퍼셉트론 생성, tol은 종료 조건, random_state는 난수의 시드
clf = Perceptron(tol=1e-3, random_state=0)

# 학습
clf.fit(X,y)

# 테스트 수행
print(X, '=>', clf.predict(X))


print('XOR 퍼셉트론')

X = [[0,0],[0,1],[1,0],[1,1]]
y = [0,1,1,0]

# 퍼셉트론 생성, tol은 종료 조건, random_state는 난수의 시드
clf = Perceptron(tol=1e-3, random_state=0)

# 학습
clf.fit(X,y)

# 테스트 수행
print(X, '=>', clf.predict(X))


# 뉴런의 출력 함수
def calculate(input):
    global weights, bias
    activation = bias
    for i in range(2) :
        activation += weights[i] * input[i]
    if activation >= 0.0:
        return 1.0
    else :
        return 0.0

# 뉴런 학습
def train_weights(X, y, l_rate, n_epoch):
    global weights, bias
    for epoch in range(n_epoch):
        sum_err = 0.0
        for row, target in zip(X, y):
            actual = calculate(row)
            error = target - actual
            bias += l_rate * error
            sum_err += error**2
            for i in range(2):
                weights[i] += l_rate*error*row[i]
            print(weights, bias)
        print('epoch=%d, 학습률=%.3f, 오류=%.3f' %(epoch,l_rate,sum_err))
        if sum_err <= 0.0 : break
    return weights

print('\nAND 연산 퍼셉트론')

X = [[0,0],[0,1],[1,0],[1,1]]
y = [0,0,0,1]

weights = [0.0, 0.0]
bias = 0.0

l_rate = 0.1
n_epoch = 15
weights = train_weights(X,y,l_rate,n_epoch)
print(weights, bias)
for i in range(4):
    print(X[i], calculate(X[i]))


print('\nOR 연산 퍼셉트론')

X = [[0,0],[0,1],[1,0],[1,1]]
y = [0,1,1,1]

weights = [0.0, 0.0]
bias = 0.0

l_rate = 0.1
n_epoch = 15
weights = train_weights(X,y,l_rate,n_epoch)
print(weights, bias)
for i in range(4):
    print(X[i], calculate(X[i]))


import numpy as np

# 시그모이드 함수
def actf(x) :
    return 1/(1+np.exp(-x))

# 시그모이드 함수의 미분값
def actf_deriv(x):
    return x*(1-x)

# AND 연산을 위한 4행x2열의 입력 행렬
# 마지막 열은 바이어스 값
X = np.array([[0,0,1],[0,1,1],[1,0,1],[1,1,1]])

y = np.array([[0],[0],[0],[1]])

np.random.seed(5)

inputs = 3      # input layer
outputs = 1     # output layer

# 가중치를 -1.0 ~ 1.0 의 난수로 초기화
weight0 = 2*np.random.random((inputs, outputs)) - 1

for i in range(1001) :
    # 순방향 계산
    layer0 = X
    net1 = np.dot(layer0, weight0)
    layer1 = actf(net1)
#    layer1[:,-1] = 1.0      # 마지막 열은 바이어스

    # 출력층의 오차 계산
    layer1_error = layer1 - y
    if i % 100 == 0 :
        print('layer1_error:%d epochs'%i)
        print(layer1_error)

    # 출력층 델타값
    layer1_delta = layer1_error * actf_deriv(layer1)

    # 은닉층 오차 계산
    # T 는 행렬의 전치를 의미
    # 역방향으로 오차를 전파할 때는 반대 방향이므로 행렬을 전치해야 함

    weight0 += -0.2 * np.dot(layer0.T, layer1_delta)

print(layer1)

