import numpy as np

# 시그모이드 함수
def actf(x) :
    return 1/(1+np.exp(-x))

# 시그모이드 함수의 미분값
def actf_deriv(x):
    return x*(1-x)

# XOR 연산을 위한 4행x2열의 입력 행렬
# 마지막 열은 바이어스 값
X = np.array([[0,0,1],[0,1,1],[1,0,1],[1,1,1]])

y = np.array([[0],[1],[1],[0]])

np.random.seed(5)

inputs = 3      # input layer
hiddens = 6     # hidden layer
outputs = 1     # output layer

# 가중치를 -1.0 ~ 1.0 의 난수로 초기화
weight0 = 2*np.random.random((inputs, hiddens)) - 1
weight1 = 2*np.random.random((hiddens, outputs)) - 1

for i in range(10001) :
    # 순방향 계산
    layer0 = X
    net1 = np.dot(layer0, weight0)
    layer1 = actf(net1)
    layer1[:,-1] = 1.0      # 마지막 열은 바이어스
    net2 = np.dot(layer1, weight1)
    layer2 = actf(net2)

    # 출력층의 오차 계산
    layer2_error = layer2 - y
    if i % 1000 == 0 :
        print('layer2_error:%d epochs'%i)
        print(layer2_error)

    # 출력층 델타값
    layer2_delta = layer2_error * actf_deriv(layer2)

    # 은닉층 오차 계산
    # T 는 행렬의 전치를 의미
    # 역방향으로 오차를 전파할 때는 반대 방향이므로 행렬을 전치해야 함
    layer1_error = np.dot(layer2_delta, weight1.T)

    layer1_delta = layer1_error * actf_deriv(layer1)

    weight1 += -0.2 * np.dot(layer1.T, layer2_delta)
    weight0 += -0.2 * np.dot(layer0.T, layer1_delta)

print(layer2)
    
