def NAND(x1, x2):
    w1, w2, theta = -0.5,-0.5,-0.7
    tmp = x1*w1+x2*w2
    if tmp < theta :
        return 0
    else :
        return 1

def OR(x1, x2):
    w1, w2, theta = 0.5,0.5,0.2
    tmp = x1*w1+x2*w2
    if tmp < theta :
        return 0
    else :
        return 1

def AND(x1, x2):
    w1, w2, theta = 0.5,0.5,0.7
    tmp = x1*w1+x2*w2
    if tmp < theta :
        return 0
    else :
        return 1

def XOR(x1, x2):
    s1 = NAND(x1, x2)
    s2 = OR(x1, x2)
    return AND(s1,s2)

print('XOR(0,0) =',XOR(0,0))
print('XOR(0,1) =',XOR(0,1))
print('XOR(1,0) =',XOR(1,0))
print('XOR(1,1) =',XOR(1,1))

import numpy as np

def NANDnp(x1, x2):
    x = np.array([x1,x2])
    w = np.array([-0.5,-0.5])
    b = 0.7
    tmp = np.sum(w*x) + b
    if tmp < 0 :
        return 0
    else :
        return 1

def ORnp(x1, x2):
    x = np.array([x1,x2])
    w = np.array([0.5,0.5])
    b = -0.2
    tmp = np.sum(w*x) + b
    if tmp < 0 :
        return 0
    else :
        return 1

def ANDnp(x1, x2):
    x = np.array([x1,x2])
    w = np.array([0.5,0.5])
    b = -0.7
    tmp = np.sum(w*x) + b
    if tmp < 0 :
        return 0
    else :
        return 1

def XORnp(x1, x2):
    s1 = NANDnp(x1, x2)
    s2 = ORnp(x1, x2)
    return ANDnp(s1,s2)

print('XORnp(0,0) =',XORnp(0,0))
print('XORnp(0,1) =',XORnp(0,1))
print('XORnp(1,0) =',XORnp(1,0))
print('XORnp(1,1) =',XORnp(1,1))
