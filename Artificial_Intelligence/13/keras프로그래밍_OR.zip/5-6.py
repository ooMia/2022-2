# 케라스 프로그래밍: 퍼셉트론 학습
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD

# OR 데이터 구축
x=[[0.0,0.0],[0.0,1.0],[1.0,0.0],[1.0,1.0]]
y=[[-1],[1],[1],[1]]

# 신경망 구조 설계
n_input=2
n_output=1

perceptron=Sequential()
perceptron.add(Dense(units=n_output,activation='tanh',input_shape=(n_input,),
                     kernel_initializer='random_uniform',bias_initializer='zeros'))

# 신경망 학습
perceptron.compile(loss='mse',optimizer=SGD(learning_rate=0.1),metrics=['mse'])
perceptron.fit(x,y,epochs=200,verbose=2)    # verbose=2 means 세대마다 한 줄 출력

# 신경망 예측
res=perceptron.predict(x)
print(res)
