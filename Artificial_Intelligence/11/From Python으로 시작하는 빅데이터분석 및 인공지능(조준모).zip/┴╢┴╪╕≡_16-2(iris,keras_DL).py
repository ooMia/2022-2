# sklearn의 iris 데이터 세트를 keras 이용한 다중분류 모델로 지도학습 다루기
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
iris = load_iris()
X = iris.data; y = iris.target
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

import tensorflow as tf
from tensorflow.keras.utils import to_categorical  # one-hot 코딩 함수
y_train = to_categorical(y_train); y_test = to_categorical(y_test)

# keras 딥러닝(4-layer) 모델 구성
model = tf.keras.models.Sequential()
model.add(tf.keras.layers.Dense(2, input_shape=(4,)))   # (4,) means (*,4) 형태의 배열
model.add(tf.keras.layers.Dense(16, activation='relu'))
model.add(tf.keras.layers.Dense(32, activation='relu'))
model.add(tf.keras.layers.Dense(3, activation='softmax'))   # 다중분류(softmax)
model.summary()

model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])     # 출력 결과와 일치하는 모델 사용
history = model.fit(X_train, y_train, validation_split=0.2, epochs=100)
print('Train on ', len(X_train), 'samples')

results = model.evaluate(X_test, y_test)
print(results)

print(X_test[:1])                   # X_test[0]으로 (*,4) 형식 표현
print(model.predict(X_test[:1]), y_test[0])
print(X_test[1:2])                  # X_test[1]으로 (*,4) 형식 표현
print(model.predict(X_test[1:2]), y_test[1])
