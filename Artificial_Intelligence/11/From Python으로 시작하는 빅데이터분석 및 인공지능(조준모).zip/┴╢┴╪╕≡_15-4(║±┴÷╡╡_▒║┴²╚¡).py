# sklearn의 비지도학습(군집화) 다루기
# k-Means 군집화
from sklearn.cluster import KMeans
import numpy as np
X = np.array([[1,5], [3,4], [2,3], [5,3], [6,2], [5,1]])
kmeans = KMeans(n_clusters=2, random_state=0)   # 군집의 중심을 랜덤하게 설정
kmeans.fit(X)
print(kmeans.labels_)           # 생성된 라벨 출력
print(kmeans.cluster_centers_)  # 라벨의 중간점 각각 출력

import matplotlib.pyplot as plt
y = kmeans.labels_
ycenter = kmeans.cluster_centers_
plt.scatter(X[:,0], X[:,1], c=y, cmap='viridis', edgecolor='k')     # 입력 데이터
plt.scatter(ycenter[:,0], ycenter[:,1], c=[0,1], s=200, cmap='viridis', edgecolor='k')  # 군집 중심
plt.show()

x_test = np.array([[1,4], [4,2]])   # 미지의 입력
y_pred = kmeans.predict(x_test)     # 예측 라벨 출력
print(x_test)
print(y_pred)
plt.scatter(X[:,0], X[:,1], c=y, cmap='viridis', edgecolor='k')     # 입력 데이터
plt.scatter(x_test[:,0], x_test[:,1], c=y_pred, s=200, marker='^', cmap='magma', edgecolor='k')  # 군집 중심
plt.show()
