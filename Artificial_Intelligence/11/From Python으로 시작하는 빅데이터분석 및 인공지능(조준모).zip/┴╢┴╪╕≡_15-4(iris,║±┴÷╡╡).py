# sklearn의 iris 데이터 세트로 비지도학습 다루기

from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
iris = load_iris()
print(iris.feature_names)
X = iris.data[:, 2:]            # Petal length, Petal width
y = iris.target
plt.xlabel('Petal length')
plt.ylabel('Petal width')
plt.axis([0, X[:,0].max()+0.2, 0, X[:,1].max()+0.2])    # xmin, xmax, ymin, ymax
plt.plot(X[:,0], X[:,1], 'bo')  # x, y, blue circle marker
plt.show()

plt.scatter(X[:,0], X[:,1], c=y, cmap='viridis', edgecolor='k') # x, y, color 순서, 색상 체계, 테두리 색상
plt.show()
