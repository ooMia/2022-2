'''
아나콘다 프롬프트 창에서 아래와 같은 명령어로 graphviz 라이브러리를 설치하고,
conda install python-graphviz 또는 pip install graphviz 또는 conda install -c anaconda graphviz
만일 에러가 발생하면, 아래의 사이트에서 다운로드하여 설치한 후 bin 폴더를 시스템 path에 추가
https://graphviz.gitlab.io/download/

오렌지와 사과의 분류를 지도학습으로 다루고, grahviz로 시각화 하기
'''

#1. 훈련 데이터 수집
features = [[270, "울퉁불퉁"], [250, "울퉁불퉁"], [220, "매끈"], [240, "매끈"]]
labels = ['오렌지', '오렌지', '사과', '사과']
#2. 입력 데이터 준비 및 분석
features = [[270, 0], [250, 0], [220, 1], [240, 1]]
labels = [0, 0, 1, 1]
#3. 학습
# sklearn의 결정트리(DecisionTreeClassifier) 이용하기
from sklearn import tree
features = [[270, 0], [250, 0], [220, 1], [240, 1]] # 0(울퉁불퉁), 1(매끈)
labels = [0, 0, 1, 1]       # 0(오렌지), 1(사과)
clf = tree.DecisionTreeClassifier()
clf.fit(features, labels)
#4. 예측 및 테스트
# 무게가 245g 이고, 표면 상태가 '매끈'한 과일은?
print(clf.predict([[245, 1]]))

# 트리 분류기의 시각화
import graphviz
dot_data = tree.export_graphviz(clf, out_file=None)
graph = graphviz.Source(dot_data)
graph.render(view=True)
#graph.view()    # 그래프가 보이지 않으면 추가로
dot_data = tree.export_graphviz(clf, out_file=None,
                                filled=True, rounded=True, special_characters=True)
graph = graphviz.Source(dot_data)
graph.render(view=True)
#graph.view()    # 그래프가 보이지 않으면 추가로
