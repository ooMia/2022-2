# sklearn의 iris 데이터 세트로 지도학습 다루기(3)

from sklearn.datasets import load_iris
iris = load_iris()
print(iris.feature_names)
print(iris.target_names)
print(iris.data[0])         # 첫번째 데이터에 저장된 feature 값
print(iris.target[0])       # 첫번째 데이터에 저장된 target 값

# sklearn의 k-NN(k-NearestNeighbors) 이용하기
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split    # train data와 test data로 분리
from sklearn.metrics import accuracy_score              # 성능 평가
x_train, x_test, y_train, y_test = train_test_split(iris.data, iris.target, test_size=0.5)

clf = KNeighborsClassifier()
clf.fit(x_train, y_train)
predictions = clf.predict(x_test)
print(accuracy_score(y_test, predictions))
