# sklearn의 iris 데이터 세트로 비지도학습(군집화) 다루기
# k-Means 군집화
from sklearn.datasets import load_iris
import matplotlib.pyplot as plt
iris = load_iris()
from sklearn.cluster import KMeans
X_iris = iris.data
y_iris = iris.target
kmeans = KMeans(n_clusters=3)
kmeans.fit(X_iris)
print(kmeans.labels_[::10])     # 생성된 라벨 출력
print(y_iris[::10])             # 원 라벨 출력

X = iris.data[:, 2:]            # Petal length, Petal width
y = iris.target
X1 = iris.data[[1, 50, 100], 2:]    # 미지의 입력
y1 = iris.target[[1, 50, 100]]
kmeans2 = KMeans(n_clusters=3, random_state=1)
kmeans2.fit(X)
y_pred = kmeans2.predict(X1)        # 예측 라벨 출력
print(y_pred)
print(y1)

plt.scatter(X[:,0], X[:,1], c=y, cmap='viridis', edgecolor='k')     # 입력 데이터
plt.scatter(X1[:,0], X1[:,1], c=y_pred, s=200, marker='^', cmap='viridis', edgecolor='k')  # 군집 중심
plt.xlabel('Petal length')
plt.ylabel('Petal width')
plt.axis([0, 8, -0.5, 3.5])     # xmin, xmax, ymin, ymax
plt.show()
